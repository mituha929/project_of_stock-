import requests
from datetime import datetime

def test_stock_quote(stock_id):
    url = "https://www.tpex.org.tw/web/stock/aftertrading/daily_close_quotes/stk_quote_result.php"
    params = {
        "l": "zh-tw",
        "d": datetime.today().strftime("%Y%m%d"),
        "s": stock_id
    }
    headers = {"User-Agent": "Mozilla/5.0"}
    r = requests.get(url, params=params, headers=headers)

    # 指定正確編碼，台灣證交所多用 big5
    r.encoding = 'utf-8'

    print("Status:", r.status_code)
    print("Preview:", r.text[:5000])

# 測試
test_stock_quote("5483")
