import os
import pandas as pd
import requests
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup

# --- 設定路徑 ---
csv_files = [
    r'C:\Users\una91\Desktop\大學 學習資料\視窗程式設計\期末專題\list_company_number.csv',
]
output_dir = r'C:\Users\una91\Desktop\大學 學習資料\視窗程式設計\期末專題\data\daily_stock_data'
os.makedirs(output_dir, exist_ok=True)

# --- 讀取所有股票代號 ---
stock_ids = set()
for file in csv_files:
    if os.path.exists(file):
        df = pd.read_csv(file)
        stock_ids.update(df.iloc[:, 0].astype(str).tolist())
    else:
        print(f"❌ 檔案不存在：{file}")
stock_id_list = list(stock_ids)

# --- 抓取單一股票的函式 ---
def fetch_stock_price_data(stock_id):
    print(f"▶ 正在查詢股票：{stock_id}")
    today = datetime.today()
    six_months_ago = today - timedelta(days=180)

    all_data = []

    current = today
    while current >= six_months_ago:
        year = current.year - 1911
        month = current.month
        url = f"https://www.twse.com.tw/exchangeReport/STOCK_DAY?response=json&date={current.strftime('%Y%m01')}&stockNo={stock_id}"
        try:
            res = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})
            json_data = res.json()

            if "data" in json_data:
                for row in json_data["data"]:
                    date = row[0].replace('/', '-')
                    close = row[6].replace(',', '')
                    all_data.append((date, close))
        except Exception as e:
            print(f"⚠ 無法取得 {stock_id} 當月資料：{e}")
        current = current - timedelta(days=30)

    if all_data:
        df = pd.DataFrame(all_data, columns=["日期", "收盤價"])
        df.to_csv(os.path.join(output_dir, f"{stock_id}.csv"), index=False, encoding='utf-8-sig')
        print(f"✅ {stock_id} 資料已儲存")
    else:
        print(f"⚠ {stock_id} 沒有可用資料")

# --- 多執行緒 ---
with ThreadPoolExecutor(max_workers=10) as executor:
    executor.map(fetch_stock_price_data, stock_id_list)