import requests
from bs4 import BeautifulSoup
import csv
from concurrent.futures import ThreadPoolExecutor, as_completed

headers = {
    "User-Agent": "Mozilla/5.0",
    "Accept-Language": "zh-TW,zh;q=0.9"
}

def fetch_price_cnyes(row, url_index, price_index, change_index, percent_index):
    try:
        url = row[url_index]
        res = requests.get(url, headers=headers, timeout=5)
        soup = BeautifulSoup(res.text, "html.parser")
        price = soup.find("h3", class_="jsx-2312976322")
        spans = soup.find("div", class_="first-row")
        span_tags = spans.find_all("span") if spans else []

        row[price_index] = price.text.strip() if price else ""
        row[change_index] = span_tags[0].text.strip() if len(span_tags) > 0 else ""
        row[percent_index] = span_tags[1].text.strip() if len(span_tags) > 1 else ""

        return all([row[price_index], row[change_index], row[percent_index]])
    except Exception as e:
        print(f"[鉅亨錯誤] {row[0]}: {e}")
        return False

def fetch_price_cmoney(stock_id, row, price_index, change_index, percent_index):
    try:
        url = f"https://www.cmoney.tw/forum/stock/{stock_id}"
        res = requests.get(url, headers=headers, timeout=5)
        soup = BeautifulSoup(res.text, "html.parser")

        price = soup.find("div", class_="stockData__price")
        change = soup.find("div", class_="stockData__quotePrice")
        percent = soup.find("div", class_="stockData__quote")

        row[price_index] = price.text.strip() if price else ""
        row[change_index] = change.text.strip() if change else ""
        row[percent_index] = percent.text.strip() if percent else ""

        return all([row[price_index], row[change_index], row[percent_index]])
    except Exception as e:
        print(f"[CMoney錯誤] {row[0]}: {e}")
        return False

def fetch_price_yahoo(stock_id, market, row, price_index, change_index, percent_index):
    try:
        suffix = "TW" if market == "上市" else "TWO"
        url = f"https://finance.yahoo.com/quote/{stock_id}.{suffix}"
        print(url)
        res = requests.get(url, headers=headers, timeout=5)
        soup = BeautifulSoup(res.text, "html.parser")

        price = soup.find("span", {"data-testid": "qsp-price"})
        change = soup.find("span", {"data-testid": "qsp-price-change"})
        percent = soup.find("span", {"data-testid": "qsp-price-change-percent"})

        row[price_index] = price.text.strip() if price else ""
        row[change_index] = change.text.strip() if change else ""
        row[percent_index] = percent.text.strip() if percent else ""

        return True
    except Exception as e:
        print(f"[Yahoo錯誤] {row[0]}: {e}")
        return False

def ensure_field(header, field):
    if field not in header:
        header.append(field)
    return header.index(field)

def fill_missing_fields(row, length):
    while len(row) < length:
        row.append("")

def run(filename):
    with open(filename, "r", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        header = next(reader)
        rows = list(reader)

    url_index = header.index("鉅亨網網址")
    market_index = header.index("市場別")
    price_index = ensure_field(header, "價格")
    change_index = ensure_field(header, "漲跌")
    percent_index = ensure_field(header, "漲跌幅度(%)")

    target_len = len(header)

    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = []
        for row in rows:
            fill_missing_fields(row, target_len)
            stock_id = row[0]
            market = row[market_index].strip()

            def task(row=row, stock_id=stock_id, market=market):
                if fetch_price_cnyes(row, url_index, price_index, change_index, percent_index):
                    return row
                if fetch_price_cmoney(stock_id, row, price_index, change_index, percent_index):
                    return row
                fetch_price_yahoo(stock_id, market, row, price_index, change_index, percent_index)
                return row

            futures.append(executor.submit(task))

        # 等待所有任務完成
        for future in as_completed(futures):
            future.result()

    # 寫入更新後的資料
    with open(filename, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)

    print(f"✅ 更新完成：{filename}")

# ✅ 呼叫三份 CSV（依需要修改）
run("list_company_number.csv")
run("over_the_counter_number.csv")
run("emerging_stock_market.csv")
